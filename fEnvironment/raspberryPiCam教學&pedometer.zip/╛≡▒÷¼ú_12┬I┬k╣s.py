import requests
import asyncio
from bleak import BleakClient
import struct
from datetime import datetime, timedelta
import json


class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return super().default(o)


address = "66:37:15:60:bd:44"
CHARACTERISTIC_UUID = "19B10001-E8F2-537E-4F6C-D104768A1214"
stepCount = 0
h = 0
# 是否已經在當天重製過步數
written_today = False


async def run():
    global written_today
    client = BleakClient(address)

    try:
        await client.connect()

        await client.start_notify(CHARACTERISTIC_UUID, notification_callback)

        while True:
            await asyncio.sleep(1.0)
            # 在這裡持續檢查時間，並在指定時間傳出0
            now = datetime.now()
            if not written_today and now.hour == 0 and now.minute == 0:
                # 等待一段時間確保上一次的發送完畢
                await asyncio.sleep(1.0)
                await write_zero(client)
                written_today = True
            elif now.hour == 23 and now.minute == 59:
                # 重置，準備處理下一天
                written_today = False
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        await client.disconnect()


async def write_zero(client):
    # 寫入0的功能
    global stepCount
    global h
    zero_value = 0
    await client.write_gatt_char(CHARACTERISTIC_UUID, struct.pack("<H", zero_value))
    h = 0
    stepCount = 0
    print("重製!!")


def notification_callback(sender, data):
    global stepCount
    global h
    h = struct.unpack("<H", data)[0]  # Use "<" for little-endian byte order
    id = "05Q119"
    time = datetime.now()
    if not written_today and time.hour == 0 and time.minute == 0:
        h = 0
    if h != stepCount:
        param1 = h
        param2 = id
        param3 = time

        url = "http://127.0.0.1:5501/receive_data"

        data_to_send = {"param1": param1, "param2": param2, "param3": param3}
        headers = {"Content-Type": "application/json"}

        json_data = json.dumps(data_to_send, cls=DateTimeEncoder)

        response = requests.post(url, data=json_data, headers=headers)

        if response.status_code == 200:
            print("已成功傳遞")
            print(param1, param2, param3)
        else:
            print("錯誤!")
        stepCount = h


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(run())
