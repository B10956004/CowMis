from flask import Flask, request, jsonify
import mysql.connector
from datetime import datetime

app = Flask(__name__)

# MySQL數據庫連接
connection = mysql.connector.connect(
    user="root", password="", host="localhost", database="pedometer"
)  # 填入你的mysql連線資訊


@app.route("/receive_data", methods=["GET", "POST"])
def receive_data():
    if request.method == "GET":
        param1 = request.args.get("param1")
        param2 = request.args.get("param2")
        param3 = request.args.get("param3")
    elif request.method == "POST":
        data = request.json  # 如果是POST請求，則可以使用request.json解析JSON數據
        param1 = data.get("param1")
        param2 = data.get("param2")
        param3 = data.get("param3")
    # 轉換型態
    param3 = datetime.strptime(param3, "%Y-%m-%dT%H:%M:%S.%f")

    # 創建游標對象
    cursor = connection.cursor()

    # 定義插入數據的SQL語句
    insert_sql = "INSERT INTO sensor_data (id, date, value) VALUES (%s, %s, %s)"

    # 執行SQL插入操作
    data_to_insert = (param2, param3, param1)
    cursor.execute(insert_sql, data_to_insert)

    # 提交事務
    connection.commit()

    # 關閉游標
    cursor.close()

    # 查看收到的參數
    print(f"Received Data: param1={param1}, param2={param2}, param3={param3}")

    return jsonify({"message": "Data received successfully"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5501)
